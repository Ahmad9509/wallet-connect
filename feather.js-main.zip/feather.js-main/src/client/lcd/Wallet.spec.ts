// import { MsgSwap, Coin, StdFee } from '../../core';
// import { MnemonicKey } from '../../key';
// import { LCDClient } from './LCDClient';
// import { TreasuryAPI, Broadcast } from './api';

describe('Wallet', () => {
  it('sends a MsgSwap transaction', async () => {
    // const terra = new LCDClient({
    //   URL: 'https://soju-lcd.terra.dev',
    //   chainID: 'soju-0014',
    // });
    // const mk = new MnemonicKey({
    //   mnemonic:
    //     'sound hour era feature bacon code drift deal raw toward soldier nation winter consider tissue jewel script result mean faculty water exist lunch betray',
    // });
    // const swap = new MsgSwap(mk.accAddress, new Coin('uluna', 1000), 'umnt');
    // const wallet = terra.wallet(mk);
    // const a = await wallet.createAndSignTx({
    //   msgs: [swap],
    //   memo: 'Hello World!',
    //   fee: new StdFee(100000, { uluna: 10000 }),
    // });
    // const b = await terra.tx.broadcast(a);
    // expect(b.height).toBeGreaterThan(0);
    // console.log(b.txhash);
  });
});
