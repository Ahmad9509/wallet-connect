export * from './TextProposal';
